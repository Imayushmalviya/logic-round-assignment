Logic Round Assignment
Language: Java
Contains 4 solved logic problems.