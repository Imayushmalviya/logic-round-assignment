public class Program3 {
 public static void main(String[] args){
  int x=4;
  int limit=(x%2==0)?x-1:x;
  int num=1;
  for(int i=1;i<=limit;i+=2){
   System.out.print(num);
   if(i+2<=limit)System.out.print(", ");
   num+=2;
  }
 }
}