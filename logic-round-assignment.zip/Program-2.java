public class Program2 {
 public static void main(String[] args){
  int x=4;
  int num=1;
  for(int i=1;i<=x;i++){
   System.out.print(num);
   if(i<x)System.out.print(", ");
   num+=2;
  }
 }
}