public class Program1 {
 double a,b; String operation;
 public Program1(double a,double b,String operation){this.a=a;this.b=b;this.operation=operation;}
 public double calculate(){
  switch(operation.toLowerCase()){
   case "add":return a+b;
   case "sub":return a-b;
   case "mul":return a*b;
   case "div":return b!=0?a/b:0;
   default:return 0;
  }
 }
 public static void main(String[] args){
  Program1 c=new Program1(10,5,"add");
  System.out.println("Result: "+c.calculate());
 }
}